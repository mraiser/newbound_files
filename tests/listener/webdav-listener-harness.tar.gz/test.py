import socket, subprocess, time, json, hashlib, os, sys
from pathlib import Path
ROOT=Path('webdav_listener_test')
(ROOT/'stop').unlink(missing_ok=True)
(ROOT/'port').unlink(missing_ok=True)
log=open(ROOT/'server.log','wb')
proc=subprocess.Popen([str(ROOT/'target/debug/webdav_listener_test')],stdout=log,stderr=log)
for _ in range(100):
  if (ROOT/'port').exists(): break
  if proc.poll() is not None: raise RuntimeError('server exited')
  time.sleep(.05)
port=int((ROOT/'port').read_text())
checks=[]
def check(name,cond,detail=''):
  print('CHECK',name,flush=True)
  if not cond: raise AssertionError(name+': '+str(detail))
  checks.append(name)
def conn(): return socket.create_connection(('127.0.0.1',port),timeout=10)
def recv_response(s, method=None):
  data=b''
  while b'\r\n\r\n' not in data: data+=s.recv(65536)
  head,rest=data.split(b'\r\n\r\n',1)
  lines=head.split(b'\r\n'); headers={}
  for line in lines[1:]:
    k,v=line.split(b':',1); headers[k.lower()]=v.strip()
  n=0 if method == 'HEAD' else int(headers.get(b'content-length',b'0'))
  while len(rest)<n: rest+=s.recv(65536)
  if method == 'HEAD':
    s.settimeout(.15)
    try: rest += s.recv(65536)
    except (TimeoutError, socket.timeout): pass
  return lines[0].decode(),headers,rest[:n]
def request(method,path='/',headers=None,body=b''):
  h={'Host':'localhost','Connection':'close'}
  if headers: h.update(headers)
  return method.encode()+b' '+path.encode()+b' HTTP/1.1\r\n'+b''.join(k.encode()+b': '+str(v).encode()+b'\r\n' for k,v in h.items())+b'\r\n'+body
def chunk(data): return ('%X'%len(data)).encode()+b'\r\n'+data+b'\r\n'
def one(method,path,headers,body=b''):
  s=conn(); s.sendall(request(method,path,headers,body)); r=recv_response(s, method); s.close(); return r
try:
  payload=bytes((i*73+19)%256 for i in range(131071))+b'\x00\r\n\xff\x00END'
  (ROOT/'payload.bin').write_bytes(payload)
  wire=chunk(payload[:7])+chunk(payload[7:65543])+chunk(payload[65543:])+b'0\r\nX-Test-Trailer: accepted\r\nDigest: yes\r\n\r\n'
  status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked','Content-Length':'999999','Connection':'close'},wire)
  check('multi-chunk binary exact parity',status.startswith('HTTP/1.1 200') and h[b'x-test-body']==payload.hex().encode(),(status,b))
  status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked'},b'0\r\n\r\n')
  check('zero chunk',status.startswith('HTTP/1.1 200') and h[b'x-test-body']==b'')
  s=conn(); split=request('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'keep-alive'})+b'4;foo="a;b"\r'
  for byte in split: s.sendall(bytes([byte])); time.sleep(.00002)
  s.sendall(b'\nDATA\r\n0\r\n\r\n'); r=recv_response(s)
  check('split size line and quoted extension',r[0].startswith('HTTP/1.1 200') and r[1].get(b'x-test-body')==b'DATA'.hex().encode(),r)
  s.sendall(request('PUT','/upload',{'Content-Length':'3','Connection':'close'},b'END')); r=recv_response(s)
  check('chunked followed by Content-Length on same connection',r[0].startswith('HTTP/1.1 200') and r[1][b'x-test-body']==b'END'.hex().encode()); s.close()
  s=conn(); s.sendall(request('PUT','/upload',{'Content-Length':'3','Connection':'keep-alive'},b'ONE')); r=recv_response(s)
  s.sendall(request('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'close'},chunk(b'TWO')+b'0\r\n\r\n')); r=recv_response(s)
  check('Content-Length followed by chunked on same connection',r[0].startswith('HTTP/1.1 200') and r[1][b'x-test-body']==b'TWO'.hex().encode()); s.close()
  bad=[b'Z\r\n',b'1 \r\nA\r\n0\r\n\r\n',b'1\nA\r\n0\r\n\r\n',b'1\r\nA\n0\r\n\r\n',b'1000000000000000000000000\r\n',b'1;=bad\r\nA\r\n0\r\n\r\n']
  for wire in bad:
    s=conn()
    s.sendall(request('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'keep-alive'},wire))
    status,h,b=recv_response(s)
    check('malformed size '+repr(wire[:15]),status.startswith('HTTP/1.1 400') and h.get(b'connection')==b'close',(status,h,b))
    s.settimeout(5)
    try: closed=s.recv(1024)==b''
    except ConnectionResetError: closed=True
    check('malformed closes without another response '+repr(wire[:15]),closed)
    s.close()
  for wire in [b'0\r\nBad Trailer\r\n\r\n',b'0\r\nX: bad\x00\r\n\r\n']:
    status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked'},wire)
    check('strict trailer '+repr(wire),status.startswith('HTTP/1.1 400') and h.get(b'connection')==b'close')
  exact=64*1024*1024
  boundary=b'0;foo=bar;baz="qux"\r\n\r\n'
  status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'close'},chunk(b'A'*exact)+boundary)
  check('exact 64 MiB aggregate accepted',status.startswith('HTTP/1.1 200') and h.get(b'x-test-length')==str(exact).encode(),(status,h,b))
  status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'keep-alive'},chunk(b'A'*(exact-1))+b'2\r\nAB')
  check('aggregate not merely single chunk cap',status.startswith('HTTP/1.1 413') and h.get(b'connection')==b'close',(status,h,b))
  status,h,b=one('PUT','/upload',{'Transfer-Encoding':'chunked','Connection':'keep-alive'},b'4000001\r\n')
  check('over-limit 413 and safe close',status.startswith('HTTP/1.1 413') and h.get(b'connection')==b'close',(status,h,b))
  raw=json.dumps({'alpha':'json works','number':42},separators=(',',':')).encode()
  status,h,b=one('POST','/json',{'Content-Type':'application/json','Content-Length':str(len(raw))},raw)
  got=json.loads(b); check('ordinary JSON POST',got['params']==json.loads(raw) and got['raw_len']==0,got)
  wire=chunk(raw[:5])+chunk(raw[5:])+b'0\r\n\r\n'
  status,h,b=one('POST','/json',{'Content-Type':'application/json','Transfer-Encoding':'chunked'},wire)
  got=json.loads(b); check('chunked JSON POST raw delivery no second read',got['raw'].encode()==raw and got['raw_len']==len(raw) and got['params']=={},got)
  for path in ['/file','/bytes','/json','/missing','/dav-head-error']:
    status,h,b=one('HEAD',path,{},b'')
    check('HEAD no body '+path,b==b'' and (path == '/missing' or b'content-length' in h),(status,h,b))
  status,h,b=one('GET','/file',{},b'')
  check('GET file exact bytes and length',b==payload and int(h[b'content-length'])==len(payload))
  status,h,b=one('HEAD','/file',{},b'')
  check('HEAD file length parity',int(h[b'content-length'])==len(payload))
  status,h,b=one('GET','/bytes',{},b'')
  check('GET bytes',b==b'bytes-body' and int(h[b'content-length'])==10)
  status,h,b=one('HEAD','/bytes',{},b'')
  check('HEAD bytes length parity',int(h[b'content-length'])==10)
  status,h,b=one('POST','/json',{'Content-Type':'application/json','Content-Length':str(64*1024*1024+1)})
  check('Content-Length cap POST',status.startswith('HTTP/1.1 413'))
  status,h,b=one('POST','/json',{'Content-Type':'application/json','Content-Length':'bad'})
  check('invalid Content-Length POST',status.startswith('HTTP/1.1 400'))
  s=conn(); s.sendall(request('HEAD','/file',{'Connection':'keep-alive'})); r=recv_response(s, 'HEAD')
  check('HEAD keepalive body boundary',r[2]==b'')
  s.sendall(request('GET','/json',{'Connection':'close'})); r=recv_response(s)
  check('request after HEAD not desynchronized',r[0].startswith('HTTP/1.1 200') and json.loads(r[2])['method']=='GET'); s.close()
  print(json.dumps({'passed':len(checks),'checks':checks,'port':port,'payload_sha256':hashlib.sha256(payload).hexdigest()},indent=2))
finally:
  try: (ROOT/'stop').unlink()
  except FileNotFoundError: pass
  (ROOT/'stop').write_text('stop')
  print('STOPPING',flush=True)
  try:
    s=conn(); s.close()
    print('WAKE SENT',flush=True)
  except Exception: pass
  try: proc.wait(timeout=5)
    # print('SERVER EXIT',proc.returncode,flush=True)
  except subprocess.TimeoutExpired: proc.kill(); proc.wait()
  log.close()
  (ROOT/'stop').unlink(missing_ok=True)
