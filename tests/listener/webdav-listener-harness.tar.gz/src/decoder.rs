// Maximum aggregate decoded bytes for one Content-Length or chunked body.
pub const MAX_RAW_BODY: usize = 64 * 1024 * 1024;
pub const MAX_CHUNK_LINE: usize = 4096;
pub const MAX_TRAILER_LINE: usize = 8192;
pub const MAX_TRAILER_BYTES: usize = 64 * 1024;

#[derive(Debug)]
pub struct ChunkedBodyError {
  pub code: i64,
  pub message: String,
}

impl ChunkedBodyError {
  fn bad_request(message: &str) -> Self {
    Self { code: 400, message: message.to_string() }
  }
  fn too_large() -> Self {
    Self { code: 413, message: "Request body exceeds the 64 MiB limit".to_string() }
  }
}

// Read a CRLF-terminated protocol line without accepting a bare LF, EOF, or
// an unbounded line. The delimiter is removed; every other byte is checked
// by the caller. This is deliberately separate from the legacy read_line,
// which is permissive and remains in use by existing MIME handling.
fn read_strict_crlf_line(stream: &mut TcpStream, limit: usize) -> Result<Vec<u8>, ChunkedBodyError> {
  let mut line = Vec::new();
  let mut one = [0u8; 1];
  loop {
    if stream.read_exact(&mut one).is_err() {
      return Err(ChunkedBodyError::bad_request("Truncated chunked request line"));
    }
    if one[0] == b'\n' {
      return Err(ChunkedBodyError::bad_request("Chunked request lines must end with CRLF"));
    }
    if one[0] == b'\r' {
      if stream.read_exact(&mut one).is_err() || one[0] != b'\n' {
        return Err(ChunkedBodyError::bad_request("Chunked request lines must end with CRLF"));
      }
      return Ok(line);
    }
    if line.len() >= limit {
      return Err(ChunkedBodyError::bad_request("Chunked request line is too long"));
    }
    line.push(one[0]);
  }
}

fn valid_token(token: &[u8]) -> bool {
  !token.is_empty() && token.iter().all(|b| matches!(b,
    b'!' | b'#' | b'$' | b'%' | b'&' | b'\'' | b'*' | b'+' | b'-' | b'.' |
    b'^' | b'_' | b'`' | b'|' | b'~' | b'0'..=b'9' | b'A'..=b'Z' | b'a'..=b'z'))
}

fn valid_chunk_extensions(line: &[u8]) -> bool {
  // RFC 9112 chunk-ext: *( ";" token [ "=" ( token / quoted-string ) ] ).
  // Whitespace around the size is intentionally not accepted; a quoted
  // extension value may contain HTAB/SP and the normal qdtext/quoted-pair
  // range, but never controls, CRLF, or an unterminated escape.
  let mut parts = line.splitn(2, |b| *b == b';');
  let size = parts.next().unwrap_or(&[]);
  if size.is_empty() || !size.iter().all(|b| b.is_ascii_hexdigit()) { return false; }
  let extensions = match parts.next() { Some(v) => v, None => return true };
  // splitn removed the semicolon separating size from the first extension.
  // Enter the parser positioned immediately AFTER that delimiter; subsequent
  // delimiters remain in `extensions` and are consumed at the loop bottom.
  let mut i = 0usize;
  while i < extensions.len() {
    let start = i;
    let start = i;
    while i < extensions.len() && extensions[i] != b';' && extensions[i] != b'=' { i += 1; }
    if !valid_token(&extensions[start..i]) { return false; }
    if i < extensions.len() && extensions[i] == b'=' {
      i += 1;
      if i < extensions.len() && extensions[i] == b'"' {
        i += 1;
        let mut closed = false;
        while i < extensions.len() {
          match extensions[i] {
            b'"' => { i += 1; closed = true; break; },
            b'\\' => {
              i += 1;
              if i >= extensions.len() || !matches!(extensions[i], b'\t' | b' '..=b'~' | 0x80..=0xff) { return false; }
              i += 1;
            },
            b'\t' | b' '..=b'!' | b'#'..=b'[' | b']'..=b'~' | 0x80..=0xff => i += 1,
            _ => return false,
          }
        }
        if !closed || (i < extensions.len() && extensions[i] != b';') { return false; }
      }
      else {
        let start = i;
        while i < extensions.len() && extensions[i] != b';' { i += 1; }
        if !valid_token(&extensions[start..i]) { return false; }
      }
    }
    if i < extensions.len() {
      if extensions[i] != b';' { return false; }
      i += 1;
    }
  }
  true
}

fn consume_trailers(stream: &mut TcpStream) -> Result<(), ChunkedBodyError> {
  let mut total = 0usize;
  loop {
    let line = read_strict_crlf_line(stream, MAX_TRAILER_LINE)?;
    if line.is_empty() { return Ok(()); }
    total = total.checked_add(line.len() + 2)
      .ok_or_else(|| ChunkedBodyError::bad_request("Trailer section is too large"))?;
    if total > MAX_TRAILER_BYTES {
      return Err(ChunkedBodyError::bad_request("Trailer section is too large"));
    }
    // No obs-fold or whitespace before the colon. Trailer field values are
    // consumed for framing only and are never exposed as request headers.
    let colon = line.iter().position(|b| *b == b':')
      .ok_or_else(|| ChunkedBodyError::bad_request("Malformed chunk trailer"))?;
    if !valid_token(&line[..colon]) { return Err(ChunkedBodyError::bad_request("Malformed chunk trailer name")); }
    if line[colon + 1..].iter().any(|b| !matches!(b, b'\t' | b' '..=b'~' | 0x80..=0xff)) {
      return Err(ChunkedBodyError::bad_request("Malformed chunk trailer value"));
    }
  }
}

// Decode exactly one chunked message. A successful return means the final
// zero-size chunk, its CRLF, and the complete trailer section were consumed;
// the next unread byte therefore belongs to the next request, if any.
pub fn read_chunked_body(stream: &mut TcpStream, max_body: usize) -> Result<Vec<u8>, ChunkedBodyError> {
  let mut decoded = Vec::new();
  loop {
    let size_line = read_strict_crlf_line(stream, MAX_CHUNK_LINE)?;
    if !valid_chunk_extensions(&size_line) {
      return Err(ChunkedBodyError::bad_request("Malformed chunk size or extension"));
    }
    let size_text = size_line.split(|b| *b == b';').next().unwrap_or(&[]);
    let size_text = std::str::from_utf8(size_text).unwrap_or("");
    let chunk_size = u64::from_str_radix(size_text, 16)
      .map_err(|_| ChunkedBodyError::bad_request("Chunk size is invalid or overflows"))?;
    if chunk_size > max_body as u64 || decoded.len() as u64 + chunk_size > max_body as u64 {
      return Err(ChunkedBodyError::too_large());
    }
    if chunk_size == 0 {
      // The trailer section starts immediately after this size line. When
      // empty, its first blank line supplies the final CRLF.
      consume_trailers(stream)?;
      return Ok(decoded);
    }
    let start = decoded.len();
    decoded.resize(start + chunk_size as usize, 0);
    if stream.read_exact(&mut decoded[start..]).is_err() {
      return Err(ChunkedBodyError::bad_request("Truncated chunk data"));
    }
    let mut crlf = [0u8; 2];
    if stream.read_exact(&mut crlf).is_err() || crlf != *b"\r\n" {
      return Err(ChunkedBodyError::bad_request("Chunk data must be followed by CRLF"));
    }
  }
}

