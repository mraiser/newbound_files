#![allow(dead_code, unused_imports, unused_variables, unused_mut, unused_parens)]
use std::thread;
use std::panic;
use std::fs;
use flowlang::datastore::*;
use flowlang::appserver::save_config;
use flowlang::appserver::fire_event;
use flowlang::flowlang::system::unique_session_id::unique_session_id;
use flowlang::flowlang::system::time::time;
use flowlang::flowlang::http::hex_decode::hex_decode;
use std::net::{TcpListener, TcpStream};
use std::sync::Once;
use ndata::sharedmutex::GlobalSharedMutex;
use ndata::heap::Heap;
use flowlang::flowlang::file::mime_type::mime_type;
use flowlang::rfc2822date::RFC2822Date;
use std::path::Path;
use std::fs::metadata;
use flowlang::sha1::SHA1;
use flowlang::base64::Base64;
use flowlang::appserver::lookup_command_id;
use flowlang::command::Command;
use flowlang::appserver::add_event_hook;
use std::io::Write;
use std::io::Read;
use core::time::Duration;
use ndata::Data;
use ndata::dataobject::DataObject;
use ndata::dataarray::DataArray;
use ndata::databytes::DataBytes;
include!("decoder.rs");
include!("listener.rs");
fn read_line(reader: &mut TcpStream) -> String {
  let mut buf = [0];
  let mut line: String = "".to_string();
  loop {
    let res = reader.read_exact(&mut buf);
    if res.is_err() { break; }
    line.push(buf[0] as char);
    if buf[0] == b'\r' {
      let res_lf = reader.read_exact(&mut buf); // Renamed res to res_lf
      if res_lf.is_err() { break; }
      line.push(buf[0] as char);
      if buf[0] == b'\n' {
        break;
      }
    }
  }
  line
}

fn read_until(reader: &mut TcpStream, c: u8, bufout: &mut Vec<u8>) -> usize {
  let mut buf = [0];
  let mut i = 0;
  loop {
    let res = reader.read_exact(&mut buf);
    if res.is_err() { break; }
    i += 1;
    bufout.push(buf[0]);
    if buf[0] == c {
      break;
    }
  }
  i
}

// Helper function to read a line as raw bytes (including \r\n)
fn read_line_as_bytes(reader: &mut TcpStream) -> std::io::Result<Vec<u8>> {
    let mut buf = [0];
    let mut line: Vec<u8> = Vec::new();
    loop {
        match reader.read_exact(&mut buf) {
            Ok(_) => {
                line.push(buf[0]); // PUSH THE BYTE
                if buf[0] == b'\n' {
                    break; // Found \n
                }
            },
            Err(e) => return if line.is_empty() { Err(e) } else { Ok(line) } // Return partial line on EOF
        }
    }
    Ok(line)
}

// Helper to parse MIME part headers
fn parse_mime_headers(stream: &mut TcpStream) -> DataObject {
    let mut headers = DataObject::new();
  headers.put_string("X-Test-Body", "");
    let mut last_key = "".to_string();
    loop {
        let line = read_line(stream); // read_line returns String, strips \r\n
        if line.trim().is_empty() {
            break; // End of headers
        }
        if line.starts_with(' ') || line.starts_with('\t') {
            // Multi-line header
            if !last_key.is_empty() {
                let old_val = headers.get_string(&last_key);
                headers.put_string(&last_key, &(old_val + "\r\n" + line.trim()));
            }
        } else {
            if let Some(idx) = line.find(':') {
                let key = line[..idx].to_uppercase().trim().to_string();
                let val = line[idx+1..].trim().to_string();
                headers.put_string(&key, &val);
                last_key = key;
            }
        }
    }
    headers
}

// Helper to parse Content-Disposition header
fn parse_content_disposition(disp: &str) -> (String, Option<String>) {
    let mut name = "".to_string();
    let mut filename = None;
    for part in disp.split(';') {
        let part = part.trim();
        if part.starts_with("name=\"") {
            name = part[6..part.len()-1].to_string();
        } else if part.starts_with("filename=\"") {
            filename = Some(part[10..part.len()-1].to_string());
        }
    }
    (name, filename)
}

// Helper to trim \r\n from the end of a byte slice
fn trim_bytes_crlf(bytes: &[u8]) -> &[u8] {
    let mut end = bytes.len();
    if end > 0 && bytes[end - 1] == b'\n' {
        end -= 1;
    }
    if end > 0 && bytes[end - 1] == b'\r' {
        end -= 1;
    }
    &bytes[..end]
}

#[derive(Debug)] pub struct WebsockConnection { pub stream: TcpStream, pub sub: DataObject }
pub static WEBSOCKHEAP: GlobalSharedMutex<Heap<WebsockConnection>> = GlobalSharedMutex::new();
fn test_handle_request(mut request: DataObject, _stream: TcpStream) -> DataObject {
  let mut session = DataObject::new();
  session.put_string("id", "isolated-test");
  request.put_object("session", session);
  let path = request.get_string("path");
  let method = request.get_string("method");
  let mut o = DataObject::new();
  let mut headers = DataObject::new();
  if path == "/json" {
    let mut body = DataObject::new();
    body.put_string("method", &method);
    body.put_object("params", request.get_object("params"));
    let bytes = request.get_bytes("body");
    body.put_int("raw_len", bytes.current_len() as i64);
    body.put_string("raw", &String::from_utf8_lossy(&bytes.get_data()));
    o.put_string("body", &body.to_string());
    o.put_string("mimetype", "application/json");
  }
  else if path == "/file" {
    o.put_string("file", "webdav_listener_test/payload.bin");
    o.put_string("mimetype", "application/octet-stream");
  }
  else if path == "/bytes" {
    o.put_bytes("body", DataBytes::from_bytes(&b"bytes-body".to_vec()));
    o.put_string("mimetype", "application/octet-stream");
  }
  else if path == "/upload" {
    let body = request.get_bytes("body");
    if body.current_len() <= 1024*1024 { headers.put_string("X-Test-Body", &hex::encode(body.get_data())); }
    headers.put_string("X-Test-Length", &body.current_len().to_string());
    o.put_string("body", "UPLOAD");
  }
  else if path == "/missing" {
    o.put_string("file", "webdav_listener_test/no-such-file");
    o.put_int("code", 404);
    o.put_string("msg", "NOT FOUND");
  }
  else if path == "/dav-head-error" {
    o.put_int("code", 404);
    o.put_string("msg", "Not Found");
    o.put_int("len", 24);
    o.put_string("body", "");
  }
  else if path == "/auth" {
    o.put_string("body", if request.get_object("headers").get_string("COOKIE") == "sessionid=test" { "AUTHORIZED" } else { "DENIED" });
  }
  else { o.put_string("body", "ROOT"); }
  o.put_object("headers", headers);
  o
}
pub fn run_test_server(port_file: String, stop_file: String) {
  let _ = flowlang::init("data");
  let listener = TcpListener::bind("127.0.0.1:0").unwrap();
  fs::write(port_file, listener.local_addr().unwrap().port().to_string()).unwrap();
  while !Path::new(&stop_file).exists() {
    if let Ok((mut stream, addr)) = listener.accept() {
      let _ = stream.set_read_timeout(Some(Duration::from_millis(3000)));
      thread::spawn(move || serve_test_stream(&mut stream, addr));
    }
  }
}
