pub fn serve_test_stream(mut stream: &mut TcpStream, remote_addr: std::net::SocketAddr) {
  let max_keep_alive = Duration::from_millis(3000);

//      let mut keepalivecount = 0;
      loop {
//        if keepalivecount > 0 { println!("keepalivecount {}", keepalivecount); }
        let mut line = read_line(&mut stream);
        let count = line.len();
//        println!("line len {}", count);
        if count == 0 { break; }
        line = (&line[0..count-2]).to_string();
        let count_space = line.find(" ").unwrap(); // Renamed count to count_space
        let method = (&line[0..count_space]).to_string();
        line = (&line[count_space+1..]).to_string();
        let count_space_opt = line.find(" "); // Renamed count to count_space_opt
        if count_space_opt.is_none() {
          println!("HTTP TCP unexpected request protocol: {}", line);
          return;
        }

        let count_space2 = count_space_opt.unwrap(); // Renamed count to count_space2
        let protocol = (&line[count_space2+1..]).to_string();
        let path = (&line[0..count_space2]).to_string();

        let mut headers = DataObject::new();
        let mut last = "".to_string();
        loop {
          let line_header = read_line(&mut stream); // Renamed line to line_header
          let mut count_header = line_header.len(); // Renamed count to count_header
          if count_header <= 2 {
            break;
          }
          if (&line_header[0..1]).to_string() != " ".to_string(){
            count_header = line_header.find(":").unwrap();
            let mut key = (&line_header[0..count_header]).to_string();
            key = key.to_uppercase();
            let mut val = (&line_header[count_header+1..]).to_string();
            val = val.trim().to_string();
            if !headers.has(&key) {
              headers.put_string(&key, &val);
            }
            else {
              let d = headers.get_property(&key);
              if d.is_array() {
                d.array().push_string(&val);
              }
              else {
                let old = d.string();
                let mut v = DataArray::new();
                v.push_string(&old);
                v.push_string(&val);
                headers.put_array(&key, v);
              }
            }
            last = key;
          }
          else {
            let d = headers.get_property(&last);
            if d.is_array(){
              let mut v = d.array();
              let n = v.len() - 1;
              let mut old = v.get_string(n);
              v.remove_property(n);
              old = old + "\r\n" + line_header.trim_end();
              v.push_string(&old);
            }
            else {
              let mut old = d.string();
              old = old + "\r\n" + line_header.trim_end();
              headers.put_string(&last, &old);
            }
          }
        }

        let mut querystring = "".to_string();
        let mut params = DataObject::new();
        let mut raw_body = DataBytes::from_bytes(&Vec::new());
        let mut request_error = "".to_string();
        let mut request_error_code = 400i64;
        let mut ka_force_close = false;
        let mut chunked_body = false;

        if headers.has("TRANSFER-ENCODING") {
          // HTTP/1.1 chunk framing is decoded before the existing content-type
          // handlers, so JSON POST, form POST, and DAV PUT all receive exactly
          // one decoded body. A declared Content-Length is ignored for chunked
          // messages; chunk bytes, never that stale length, delimit the request.
          let transfer_encoding = headers.get_string("TRANSFER-ENCODING");
          if transfer_encoding.eq_ignore_ascii_case("chunked") {
            match read_chunked_body(&mut stream, MAX_RAW_BODY) {
              Ok(body_buf) => {
                raw_body = DataBytes::from_bytes(&body_buf);
                headers.put_string("CONTENT-LENGTH", &body_buf.len().to_string());
                headers.remove_property("TRANSFER-ENCODING");
                chunked_body = true;
              },
              Err(e) => {
                request_error_code = e.code;
                request_error = e.message;
                // Consume this response only. Never interpret an invalid chunk
                // line, body suffix, or trailer as another HTTP request.
                ka_force_close = true;
              }
            }
          }
          else if !transfer_encoding.eq_ignore_ascii_case("identity") {
            request_error_code = 501;
            request_error = format!("Transfer-Encoding {} is not supported", transfer_encoding);
            // An unsupported coding has no known request boundary. Do not
            // reuse the connection and possibly parse its payload as HTTP.
            ka_force_close = true;
          }
        }

        if method == "POST" && !chunked_body && request_error.is_empty() {
          // A chunked body has already been consumed above and is passed to
          // the command as raw_body. Never read its payload a second time.
          // The legacy Content-Length POST parsers retain their socket path.
          let clstr = headers.try_get_string("CONTENT-LENGTH").unwrap_or_else(|_| "0".to_string());
          let ctstr = match headers.has("CONTENT-TYPE") {
            true => headers.get_string("CONTENT-TYPE"),
            false => "text/plain".to_string()
          };
          let max = match clstr.parse::<usize>() {
            Ok(n) => n,
            Err(_) => {
              request_error = "Invalid Content-Length".to_string();
              ka_force_close = true;
              0
            }
          };
          if max > MAX_RAW_BODY {
            request_error_code = 413;
            request_error = "Request body exceeds the 64 MiB limit".to_string();
            ka_force_close = true;
          }

          let s = ctstr.to_lowercase();
          if request_error.is_empty() && s.contains("application/json") {
            if max > 0 {
                let mut body_buf = vec![0; max];
                match stream.read_exact(&mut body_buf) {
                    Ok(_) => {
                        let body_str = String::from_utf8_lossy(&body_buf).to_string();
                        let json_params = DataObject::from_string(&body_str);
                        params = json_params;
                    },
                    Err(e) => {
                        request_error = format!("Error reading JSON body: {}", e);
                        ka_force_close = true;
                    }
                }
            }
          }
          else if request_error.is_empty() && s.starts_with("multipart/form-data") {
            // MULTIPART
            let boundary = ctstr.split("boundary=").nth(1).map(|s| s.trim_matches('"'));
            if let Some(boundary_str) = boundary {
                let boundary_sep = "--".to_string() + boundary_str;
                let boundary_end = boundary_sep.clone() + "--";

                let mut temp_dir = std::env::temp_dir();
                temp_dir.push("newbound_uploads");
                temp_dir.push(unique_session_id()); // Unique dir per request
                if let Err(e) = fs::create_dir_all(&temp_dir) { 
                    println!("Failed to create temp dir: {}", e);
                    // Continue with empty params
                }

                // Read until first boundary
                loop {
                    let line = read_line(&mut stream);
                    if line.is_empty() { break; } // Stream error
                    if line.trim() == boundary_sep { break; } // Found start
                }

                // Loop over parts
                loop {
                    let part_headers = parse_mime_headers(&mut stream);
                    if !part_headers.has("CONTENT-DISPOSITION") {
                        // Invalid part, probably end of stream
                        break;
                    }

                    let (name, filename_opt) = parse_content_disposition(&part_headers.get_string("CONTENT-DISPOSITION"));
                    if name.is_empty() { continue; } // Skip part with no name

                    let mut part_data: Vec<u8> = Vec::new();
                    let mut is_end = false;

                    // Read part body
                    loop {
                        let line_bytes_res = read_line_as_bytes(&mut stream);
                        if line_bytes_res.is_err() { 
                            is_end = true; // Stream ended unexpectedly
                            break; 
                        }
                        let line_bytes = line_bytes_res.unwrap();
                        
                        // Check if this line is a boundary
                        let line_trimmed = trim_bytes_crlf(&line_bytes); // Trim only \r\n
                        
                        if line_trimmed == boundary_sep.as_bytes() {
                            break; // End of this part
                        }
                        if line_trimmed == boundary_end.as_bytes() {
                            is_end = true;
                            break; // End of all parts
                        }
                        
                        // Not a boundary, add to data
                        part_data.extend_from_slice(&line_bytes);
                    }
                    
                    // We read one line too many (the boundary). The *actual* data
                    // ends before the \r\n of the *previous* line.
                    if part_data.ends_with(b"\r\n") {
                        part_data.truncate(part_data.len() - 2);
                    }

                    // Process the data
                    if let Some(filename) = filename_opt {
                        if !filename.is_empty() {
                            // It's a file
                            let temp_path = temp_dir.join(&filename);
                            if let Err(e) = fs::write(&temp_path, &part_data) { // Pass part_data by ref
                                println!("Failed to write temp file: {}", e);
                            } else {
                                params.put_string(&name, temp_path.to_str().unwrap_or(""));
                            }
                        } else {
                             // Field with an empty filename, treat as text
                             params.put_string(&name, &String::from_utf8_lossy(&part_data));
                        }
                    } else {
                        // It's form data
                        params.put_string(&name, &String::from_utf8_lossy(&part_data));
                    }

                    if is_end { break; }
                }

                // Cleanup temp dir
                if let Err(e) = fs::remove_dir_all(&temp_dir) {
                    println!("Failed to clean temp dir: {}", e);
                }

            } else {
                println!("Multipart request without boundary!");
            }
          }
          else if request_error.is_empty() {
            // DEFAULT: Handle application/x-www-form-urlencoded
            let mut max_i64 = max as i64; // Use i64 for compatibility with old logic
            while max_i64 > 0 {
              let mut b_post = false; // Renamed b to b_post
              let mut buf = vec![];
              let n = read_until(&mut stream, b'=', &mut buf);
              max_i64 -= n as i64;
              let mut key = String::from_utf8_lossy(&buf).to_string();
              if key.ends_with("=") {
                key = (&key[..n-1]).to_string();
              }

              buf = vec![];
              let n_val = read_until(&mut stream, b'&', &mut buf); // Renamed n to n_val
              max_i64 -= n_val as i64;
              let mut value = String::from_utf8_lossy(&buf).to_string();
              if value.ends_with("&") {
                value = (&value[..n_val-1]).to_string();
              }
              else { b_post = true; }

              key = key.replace("+"," ");
              value = value.replace("+"," ");
              key = hex_decode(key);
              value = hex_decode(value);

              params.put_string(&key, &value);

              if b_post { break; }
            }
          }
        }

        else if method != "GET" && method != "HEAD" && !chunked_body {
          // Chunked bodies of every method were already consumed above.
          // Preserve arbitrary non-POST request bodies (WebDAV PUT/PROPFIND,
          // JSON PATCH, etc.) without decoding or newline transformation.
          // Consume or reject the body on every path so keep-alive stays framed.
          let content_length = headers.try_get_string("CONTENT-LENGTH").unwrap_or_else(|_| "0".to_string());
          let body_len = match content_length.parse::<usize>() {
            Ok(n) => n,
            Err(_) => {
              request_error = "Invalid Content-Length".to_string();
              ka_force_close = true;
              0
            }
          };
          if request_error.is_empty() && body_len > MAX_RAW_BODY {
            request_error_code = 413;
            request_error = "Request body exceeds the 64 MiB limit".to_string();
            // The oversized payload is still on the socket. Do not consume
            // part of it and mistake its remainder for another request.
            ka_force_close = true;
          }
          if request_error.is_empty() && body_len > 0 {
            let mut body_buf = vec![0; body_len];
            match stream.read_exact(&mut body_buf) {
              Ok(_) => raw_body = DataBytes::from_bytes(&body_buf),
              Err(e) => {
                request_error = format!("Error reading request body: {}", e);
                ka_force_close = true;
              }
            }
          }
        }

        let cmd_path:String; // Renamed cmd to cmd_path
        if path.contains("?"){
          let i = path.find("?").unwrap();
          cmd_path = path[0..i].to_string();
          querystring = path[i+1..].to_string();
          let mut oneline = querystring.to_owned();
          let mut oneparam:String;
          while oneline.len() > 0 {
            if oneline.contains("&")  {
              let i_amp = oneline.find("&").unwrap(); // Renamed i to i_amp
              oneparam = oneline[0..i_amp].to_string();
              oneline = oneline[i_amp+1..].to_string();
            }
            else {
              oneparam = oneline;
              oneline = "".to_string();
            }

            if oneparam.contains("=") {
              let i_eq = oneparam.find("=").unwrap(); // Renamed i to i_eq
              let key = hex_decode(oneparam[0..i_eq].to_string());
              let value = hex_decode(oneparam[i_eq+1..].to_string());
              params.put_string(&key, &value);
            }
          }
        }
        else {
          cmd_path = path;
        }
        let loc = remote_addr.to_string();
        headers.put_string("nn-userlocation", &loc);
        let mut request = DataObject::new();

        if headers.has("ACCEPT-LANGUAGE"){
          let lang = headers.get_string("ACCEPT-LANGUAGE");
          request.put_string("language", &lang);
        }
        else {
          request.put_string("language", "*");
        }

        //if headers.has("HOST"){
        //  let h = headers.get_string("HOST");
        //  request.put_string("host", &h);
        //}
        request.put_string("host", &headers.try_get_string("HOST").unwrap_or("".to_string()));

        //if headers.has("REFERER"){
        //  let h = headers.get_string("REFERER");
        //  request.put_string("referer", &h);
        //}
        request.put_string("referer", &headers.try_get_string("REFERER").unwrap_or("".to_string()));
        
        request.put_string("protocol", &protocol);
        request.put_string("path", &cmd_path);
        request.put_string("loc", &loc);
        request.put_string("method", &method);
        request.put_string("querystring", &querystring);
        request.put_object("headers", headers.clone()); // Clone headers before moving to request
        request.put_object("params", params);
        request.put_bytes("body", raw_body);
        if !request_error.is_empty() {
          request.put_string("request_error", &request_error);
          request.put_int("request_error_code", request_error_code);
        }

        let now = time();
        request.put_int("timestamp", now);

        // isolated harness: no event hook

        let mut ka;
        if headers.has("CONNECTION") { ka = headers.get_string("CONNECTION"); }
        else { ka = "close".to_string(); }
        if ka_force_close { ka = "close".to_string(); }

        let mut response_obj = DataObject::new(); // Renamed response to response_obj to avoid conflict
        let dataref = response_obj.data_ref;

        let result = panic::catch_unwind(|| {
          let mut p = DataObject::get(dataref);
          if !request_error.is_empty() {
            let mut o = DataObject::new();
            o.put_int("code", request_error_code);
            o.put_string("msg", "BAD REQUEST");
            o.put_string("mimetype", "text/plain; charset=utf-8");
            o.put_string("body", &request_error);
            p.put_object("a", o);
          }
          else {
            let o = test_handle_request(request.clone(), stream.try_clone().unwrap());
            p.put_object("a", o);
          }
        });

        match result {
          Ok(_x) => (),
          Err(e) => {
            let s = match e.downcast::<String>() {
              Ok(panic_msg) => format!("{}", panic_msg),
              Err(_) => "unknown error".to_string()
            };

            let mut o = DataObject::new();
            let s_html = format!("<html><head><title>500 - Server Error</title></head><body><h2>500</h2>Server Error: {}</body></html>", s); // Renamed s to s_html
            o.put_string("body", &s_html);
            o.put_int("code", 500);
            o.put_string("mimetype", "text/html");
            response_obj.put_object("a", o); // Use response_obj
          }
        }

        if headers.has("SEC-WEBSOCKET-KEY") {
          fire_event("app", "WEBSOCK_END", request.clone());
          let sockref = request.get_int("websocket_id");
          // Modified: Use .lock()
          WEBSOCKHEAP.lock().decr(sockref as usize);
        }
        else {
          let mut final_response = response_obj.get_object("a").clone(); // Use response_obj, Renamed response to final_response

          let body_content:String; // Renamed body to body_content
          let mimetype:String;
          let len:i64;
          let code:u16;
          let msg:String;
          let mut response_headers:DataObject; // Renamed headers to response_headers

          let mut isfile = final_response.has("file") && final_response.get_property("file").is_string();
          let mut isbytes = final_response.has("body") && final_response.get_property("body").is_bytes();

          if isbytes {
            let bytes = final_response.get_bytes("body");
            let mt = bytes.get_mime_type();
            if mt.is_some() { final_response.put_string("mimetype", &mt.unwrap()); }
            if bytes.current_len() == 3 && bytes.get_data() == [52, 48, 52] { // "404"
              let p = "html/404.html";
              if Path::new(&p).exists() {
                final_response.put_string("file", &p);
                final_response.put_string("mimetype", "text/html");
                isfile = true;
              }
              final_response.put_int("code", 404);
              final_response.put_string("msg", "NOT FOUND");
              isbytes = false;
            }
          }

          if isfile { body_content = final_response.get_string("file"); }
          else if final_response.has("body") && final_response.get_property("body").is_string() { body_content = final_response.get_string("body"); }
          else { body_content = "".to_owned(); }

          if final_response.has("code") && final_response.get_property("code").is_int() { code = final_response.get_int("code") as u16; }
          else { code = 200; }

          if final_response.has("msg") && final_response.get_property("msg").is_string() { msg = final_response.get_string("msg"); }
          else {
            if code < 200 { msg = "INFO".to_string(); }
            else if code < 300 { msg = "OK".to_string(); }
            else if code < 400 { msg = "REDIRECT".to_string(); }
            else if code < 500 { msg = "CLIENT ERROR".to_string(); }
            else { msg = "SERVER ERROR".to_string(); }
          }

          if final_response.has("headers") && final_response.get_property("headers").is_object() { response_headers = final_response.get_object("headers"); }
          else { response_headers = DataObject::new(); }

          if final_response.has("mimetype") && final_response.get_property("mimetype").is_string() { mimetype = final_response.get_string("mimetype"); }
          else if response_headers.has("Content-Type") { mimetype = response_headers.get_string("Content-Type"); }
          else if isfile { mimetype = mime_type(cmd_path.clone()); } // Use cmd_path
          else { mimetype = "text/plain".to_string(); }

          if final_response.has("len") && final_response.get_property("len").is_int() { len = final_response.get_int("len"); }
          else if response_headers.has("Content-Length") { len = response_headers.get_int("Content-Length"); }
          else if isfile {
            let lenx = fs::metadata(&body_content);
            if lenx.is_ok() { len = lenx.unwrap().len() as i64; }
            else {
              final_response.put_int("code", 404); // Modify final_response
              final_response.put_string("msg", "NOT FOUND");
              isfile = false;
              len = -1;
            }
          }
          else if isbytes {
            let bytes = final_response.get_bytes("body");
            let x = bytes.stream_len();
            if x != 0 { len = x as i64; }
            else { len = -1; }
          }
          else { len = body_content.len() as i64; }

          let date = RFC2822Date::new(now).to_string();

          response_headers.put_string("Date", &date);
          response_headers.put_string("Content-Type", &mimetype);
          if len == -1 { ka = "close".to_string(); }
          else { response_headers.put_string("Content-Length", &len.to_string()); }
          // Every response advertises whether its connection can be reused.
          // HEAD retains the equivalent GET length but suppresses every body
          // representation below: regular files, byte streams, and strings.
          response_headers.put_string("Connection", &ka);

          let session_id_cookie = "isolated-test".to_string(); // Renamed session_id to session_id_cookie
          let later = now + 31536000000;
          let cookie = "sessionid=".to_string() + &session_id_cookie + "; Path=/; Expires=" + &RFC2822Date::new(later).to_string();
          response_headers.put_string("Set-Cookie", &cookie);

          let cors = "*";
          response_headers.put_string("Access-Control-Allow-Origin", cors);

          let mut reshead = "HTTP/1.1 ".to_string() + &code.to_string() + " " + &msg + "\r\n";
          for (k,v) in response_headers.objects() {
            reshead = reshead + &k + ": " + &Data::as_string(v) + "\r\n";
          }
          reshead = reshead + "\r\n";

          if method == "HEAD" {
            let _x = stream.write(reshead.as_bytes());
          }
          else if isfile {
            let _x = stream.write(reshead.as_bytes());
            let mut file = fs::File::open(&body_content).unwrap();
            let chunk_size = core::cmp::min(file.metadata().unwrap().len(), 65024) as usize;
            loop {
              let mut chunk = Vec::with_capacity(chunk_size);
              let n = std::io::Read::by_ref(&mut file).take(chunk_size as u64).read_to_end(&mut chunk).unwrap();
              if n == 0 { break; }
              let x = stream.write(&chunk);
              if x.is_err() { break; }
              if n < chunk_size { break; }
            }
          }
          else if isbytes {
            let bytes = final_response.get_bytes("body");
            let _x = stream.write(reshead.as_bytes());
            let mut timeout = 0;
            while bytes.is_read_open() {
              let chunk_size = core::cmp::max(0x4000, bytes.current_len()); // Ensure chunk_size is not zero if current_len is zero
              let chunk = bytes.read(chunk_size);
              let x = stream.write(&chunk);
              if x.is_err() { break; }
              if chunk.len() == 0 {
                timeout += 1;
                let beat = Duration::from_millis(timeout);
                thread::sleep(beat);
                if timeout > 246 { println!("Unusually long wait for stream data... Abort"); break; }
              }
              else { timeout = 0; }
            }
            bytes.close_read();
          }
          else {
            let full_response_str = reshead + &body_content; // Renamed response to full_response_str
            let _x = stream.write(full_response_str.as_bytes());
          }

          // isolated harness: no event hook // Use final_response

          let _x = stream.flush();
        }
        if ka.to_lowercase() != "keep-alive" { break; }

        DataStore::gc();
      }
}
